class PrinterModel {
  final String name;
  final int address;

  PrinterModel({
    required this.name,
    required this.address,
  });
}

final printers = [
  PrinterModel(
    name: 'Galaxy A30',
    address: 12324567412,
  ),
  PrinterModel(
    name: 'Galaxy A30',
    address: 12324567412,
  ),
  PrinterModel(
    name: 'Galaxy A30',
    address: 12324567412,
  ),
];
